#pragma once

using namespace Ogre;

class KalsDevice
{
public:
	KalsDevice(void);
	~KalsDevice(void);

	bool init();
	void loadResources();
	void createScene();

private:
	Root * mRoot;
	SceneManager * mSceneManager;
	RenderWindow * mWindow;
	Camera * mCamera;
	Viewport * mViewport;
	InputManager * mFrameListener;
	Physics * mPhysics;
	//DebugDrawer * mDebugDrawer;
	CharacterControllerManager * mCharacter;
};

