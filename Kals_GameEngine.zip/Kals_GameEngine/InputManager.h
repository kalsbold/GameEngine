#pragma once

#include <Ogre.h>
#include <OIS.h>
#include "Physics.h"
#include "cc_Manager.h"

using namespace Ogre;

class InputManager : public FrameListener, public OIS::KeyListener, public OIS::MouseListener
{
public:
	InputManager(RenderWindow * win, Camera * cam, Physics * phscs, /*DebugDrawer * debugDrawer,*/ CharacterControllerManager * ch);
	~InputManager(void);
	bool frameRenderingQueued(const FrameEvent & evt);
	bool frameStarted(const FrameEvent & evt);
	bool keyPressed(const OIS::KeyEvent & evt);
	bool keyReleased(const OIS::KeyEvent & evt);
	bool mouseMoved(const OIS::MouseEvent & evt);
	bool mousePressed(const OIS::MouseEvent & evt, OIS::MouseButtonID id);
	bool mouseReleased(const OIS::MouseEvent & evt, OIS::MouseButtonID id);
private:
	Camera * mCamera;
	Timer mTimer;
	RenderWindow * mWindow;
	bool mShutdown;

	OIS::InputManager * mInputManager;
	OIS::Keyboard * mKeyboard;
	OIS::Mouse * mMouse;

	Physics * mPhysics;
	bool mEnabledPhysicsDebugDraw;
	//DebugDrawer * mDebugDrawer;

	CharacterControllerManager * me;
};

