#ifndef CC_MANAGER_H
#define CC_MANAGER_H



#include "cc_physics.h"
#include "cc_player.h"

using namespace Ogre;

class CharacterControllerManager
{
	private:
		static const int RUN_SPEED = 17;
		static const int TURN_SPEED = 500;
		static const int CAM_HEIGHT = 2;

		CharacterController_Physics * mCCPhysics;
		CharacterController_Player * mCCPlayer;

		SceneManager * mSceneManager;

		Camera * mCamera;
		SceneNode * mBodyNode;
		SceneNode * mCameraPivot;
		SceneNode * mCameraGoal;
		SceneNode * mCameraNode;
		Real mPivotPitch;
		Vector3 mWalkDirection;

		bool mIsFalling;
		bool mJumped;

		Vector3 mGoalDirection;
		Vector3 mKeyDirection;


	public:
		CharacterControllerManager(SceneManager * scnMgr, Camera * cam, btPairCachingGhostObject * ghostObject,
									btConvexShape * convexShape, btScalar stepHeight, btCollisionWorld * collisionWorld,
									Vector3 & origin, int upAxis = 1
									);

		CharacterControllerManager(SceneManager * scnMgr, CharacterController_Player * ccPlayer,
									CharacterController_Physics * ccPhysics
									);

		CharacterController_Player * getCCPlayer();
		CharacterController_Physics * getCCPhysics();
		void injectKeyDown(const OIS::KeyEvent & evt);
		void injectKeyUp(const OIS::KeyEvent & evt);
		void injectMouseMove(const OIS::MouseEvent & evt);
		void updateCharacter(Real dt);


	private:
		void setupCamera(Camera * cam);
		void updateCamera(Real deltaTime);
		void updateCameraGoal(Real deltaYaw, Real deltaPitch, Real deltaZoom);
		Quaternion updateOrientation(Real deltaTime);
};

#endif // CC_MANAGER_H
