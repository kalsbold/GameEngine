#include "InputManager.h"


InputManager::InputManager(RenderWindow * win, Camera * cam, Physics * phscs, /*DebugDrawer * debugDrawer,*/ CharacterControllerManager * ch):
	mWindow(win),
	mCamera(cam),
	mPhysics(phscs),
	/*mDebugDrawer(debugDrawer),*/
	me(ch),
	mShutdown(false)
{
	mEnabledPhysicsDebugDraw = false;

	OIS::ParamList pl;
	unsigned int windowHnd = 0;
	std::stringstream windowHndStr;

	win->getCustomAttribute("WINDOW", &windowHnd);
	windowHndStr << windowHnd;

	pl.insert(std::make_pair("WINDOW", windowHndStr.str()));

	mInputManager = OIS::InputManager::createInputSystem(pl);
	mKeyboard = static_cast<OIS::Keyboard*>(mInputManager->createInputObject(OIS::OISKeyboard, true));
	mMouse = static_cast<OIS::Mouse*>(mInputManager->createInputObject(OIS::OISMouse, true));

	mKeyboard->setEventCallback(this);
	mMouse->setEventCallback(this);
}


InputManager::~InputManager(void)
{
	mInputManager->destroyInputObject(mKeyboard);
	OIS::InputManager::destroyInputSystem(mInputManager);
}

bool InputManager::frameRenderingQueued(const FrameEvent & evt)
{
	if (mWindow->isClosed() || mShutdown)
		return false;

	me->updateCharacter(evt.timeSinceLastFrame);

	return true;
}

bool InputManager::frameStarted(const FrameEvent & evt)
{
	mPhysics->getDynamicsWorld()->stepSimulation(1 / 100.f, 10);

	//mDebugDrawer->setDebugMode(mEnabledPhysicsDebugDraw);
	//mDebugDrawer->step();

	mKeyboard->capture();
	mMouse->capture();

	return true;
}

bool InputManager::keyPressed(const OIS::KeyEvent & evt)
{
	me->injectKeyDown(evt);

	switch (evt.key)
	{
	case OIS::KC_ESCAPE:
		mShutdown = true;
		break;

	case OIS::KC_R:
		PolygonMode pm;

		switch (mCamera->getPolygonMode())
		{
		case PM_SOLID:
			pm = PM_WIREFRAME;
			break;

		case PM_WIREFRAME:
			pm = PM_POINTS;
			break;

		case PM_POINTS:
			pm = PM_SOLID;
			break;

		default:
			pm = PM_SOLID;
		}

		mCamera->setPolygonMode(pm);
		break;

	case OIS::KC_T:
		mEnabledPhysicsDebugDraw = !mEnabledPhysicsDebugDraw;
		break;
	}

	return true;
}

bool InputManager::keyReleased(const OIS::KeyEvent & evt)
{
	me->injectKeyUp(evt);
	return true;
}

bool InputManager::mouseMoved(const OIS::MouseEvent & evt)
{
	me->injectMouseMove(evt);
	return true;
}

bool InputManager::mousePressed(const OIS::MouseEvent & evt, OIS::MouseButtonID id)
{
	if (evt.state.buttonDown(OIS::MB_Left))
		mPhysics->shootBox(mCamera->getPosition());

	return true;
}

bool InputManager::mouseReleased(const OIS::MouseEvent & evt, OIS::MouseButtonID id)
{
	return true;
}
