#include <Ogre.h>
#include <OIS.h>
#include <btBulletDynamicsCommon.h>
#include "Physics.h"
#include "cc_Manager.h"
#include "InputManager.h"
#include "KalsDevice.h"


KalsDevice::KalsDevice(void):
	mRoot(0),
	mSceneManager(0),
	mWindow(0),
	mCamera(0),
	mViewport(0),
	mFrameListener(0),
	mPhysics(0),
	/*mDebugDrawer(0),*/
	mCharacter(0)
{
}



KalsDevice::~KalsDevice(void)
{
	delete mFrameListener;
	delete mRoot;
}


bool KalsDevice::init()
{
	mRoot = new Root();

	if (!mRoot->showConfigDialog())
		return false;

	mWindow = mRoot->initialise(true, "ogre3d + bullet");
	mSceneManager = mRoot->createSceneManager(ST_GENERIC);

	mCamera = mSceneManager->createCamera("Cam");
	mCamera->setNearClipDistance(5);

	mViewport = mWindow->addViewport(mCamera);
	mViewport->setBackgroundColour(ColourValue(0, 0, 0));
	mCamera->setAspectRatio(Real(mViewport->getActualWidth()) / Real(mViewport->getActualHeight()));

	mPhysics = new Physics();
	//mDebugDrawer = new DebugDrawer(mSceneManager->getRootSceneNode(), mPhysics->getDynamicsWorld());
	//mPhysics->getDynamicsWorld()->setDebugDrawer(mDebugDrawer);

	loadResources();
	createScene();

	mFrameListener = new InputManager(mWindow, mCamera, mPhysics,/* mDebugDrawer,*/ mCharacter);
	mRoot->addFrameListener(mFrameListener);


	mRoot->startRendering();

	return true;
}

void KalsDevice::loadResources()
{
	ConfigFile cf;
	cf.load("resources_d.cfg");
	ConfigFile::SectionIterator sectionIter = cf.getSectionIterator();

	String sectionName, typeName, dataName;
	ConfigFile::SettingsMultiMap * settings;
	ConfigFile::SettingsMultiMap::iterator i;

	while (sectionIter.hasMoreElements())
	{
		sectionName = sectionIter.peekNextKey();
		settings = sectionIter.getNext();

		for (i = settings->begin(); i != settings->end(); ++i)
		{
			typeName = i->first;
			dataName = i->second;

			ResourceGroupManager::getSingleton().addResourceLocation(dataName, typeName, sectionName);
		}
	}

	ResourceGroupManager::getSingleton().initialiseAllResourceGroups();
}

void KalsDevice::createScene()
{
	Light * light = mSceneManager->createLight("Light");
	light->setType(Light::LT_DIRECTIONAL);
	light->setDirection(Vector3(1, -1, 0));


	Plane plane(Vector3::UNIT_Y, -5);
	SceneNode * planeNode = mSceneManager->getRootSceneNode()->createChildSceneNode(Vector3(0, 4, 0));

	MeshManager::getSingleton().createPlane("plane", ResourceGroupManager::DEFAULT_RESOURCE_GROUP_NAME, plane, 1500, 1500, 200, 200, true, 1, 5, 5, Vector3::UNIT_Z);
	Entity * ground = mSceneManager->createEntity("LightPlaneEntity", "plane");
	ground->setMaterialName("Examples/BeachStones");
	planeNode->attachObject(ground);
	mPhysics->addStaticPlane(planeNode);

	Plane ceiling(Vector3::UNIT_Y, -5);
	SceneNode * ceilingNode = mSceneManager->getRootSceneNode()->createChildSceneNode(Vector3(0, 8, 0));

	MeshManager::getSingleton().createPlane("ceiling", ResourceGroupManager::DEFAULT_RESOURCE_GROUP_NAME, ceiling, 10, 10, 2, 2, true, 1, 5, 5, Vector3::UNIT_Z);
	Entity * ceilingEnt = mSceneManager->createEntity("CeilingEntity", "ceiling");
	ceilingEnt->setMaterialName("Examples/BumpyMetal");
	ceilingNode->attachObject(ceilingEnt);
	mPhysics->addStaticPlane2(ceilingNode);



	SceneNode * Box = mSceneManager->getRootSceneNode()->createChildSceneNode(Vector3(0,20,0));
	Entity * BoxNode = mSceneManager->createEntity("cube.mesh");
	Box->attachObject(BoxNode);
	Box->setScale(Vector3(0.05,0.05,0.05));
	mPhysics->addDynamicBox(Box,20);

	SceneNode * Box2 = mSceneManager->getRootSceneNode()->createChildSceneNode(Vector3(10,20,0));
	Entity * BoxNode2 = mSceneManager->createEntity("cube.mesh");
	Box2->attachObject(BoxNode2);
	Box2->setScale(Vector3(0.05,0.05,0.05));
	mPhysics->addDynamicBox(Box2,20);

	SceneNode * Box3 = mSceneManager->getRootSceneNode()->createChildSceneNode(Vector3(20,20,0));
	Entity * BoxNode3 = mSceneManager->createEntity("cube.mesh");	
	Box3->attachObject(BoxNode3);
	Box3->setScale(Vector3(0.05,0.05,0.05));
	mPhysics->addDynamicBox(Box3,20);

	SceneNode * Box4 = mSceneManager->getRootSceneNode()->createChildSceneNode(Vector3(30,20,0));
	Entity * BoxNode4 = mSceneManager->createEntity("cube.mesh");
	//BoxNode->setMaterialName("cube.mesh");
	Box4->attachObject(BoxNode4);
	Box4->setScale(Vector3(0.05,0.05,0.05));
	mPhysics->addDynamicBox(Box4,20);

	SceneNode * Box5 = mSceneManager->getRootSceneNode()->createChildSceneNode(Vector3(20,30,0));
	Entity * BoxNode5 = mSceneManager->createEntity("cube.mesh");
	//BoxNode->setMaterialName("cube.mesh");
	Box5->attachObject(BoxNode5);
	Box5->setScale(Vector3(0.05,0.05,0.05));
	mPhysics->addDynamicBox(Box5,20);

	SceneNode * Box6 = mSceneManager->getRootSceneNode()->createChildSceneNode(Vector3(30,30,0));
	Entity * BoxNode6 = mSceneManager->createEntity("cube.mesh");
	//BoxNode->setMaterialName("cube.mesh");
	Box6->attachObject(BoxNode6);
	Box6->setScale(Vector3(0.05,0.05,0.05));
	mPhysics->addDynamicBox(Box6,20);


	/// -- CHARACTER CONTROLLER --

	btTransform startTransform;
	startTransform.setIdentity();
	startTransform.setOrigin(btVector3(10, 2, 0));
	Vector3 origin(10, 2, 0);

	btPairCachingGhostObject * characterGhostObject = new btPairCachingGhostObject();
	characterGhostObject->setWorldTransform(startTransform);

	btScalar characterHeight = 10.f;
	btScalar characterWidth = 1.f;

	btConvexShape * capsule = new btCapsuleShape(characterWidth, characterHeight);

	mPhysics->addCollisionShape(capsule);
	characterGhostObject->setCollisionShape(capsule);
	characterGhostObject->setCollisionFlags(btCollisionObject::CF_CHARACTER_OBJECT);

	// duck setup
	btConvexShape * duck = new btCapsuleShape(characterWidth, characterHeight / 3);
	mPhysics->addCollisionShape(duck);

	btScalar stepHeight = 0.3f;
	mCharacter = new CharacterControllerManager(mSceneManager, mCamera, characterGhostObject, capsule, stepHeight, mPhysics->getCollisionWorld(), origin);
	mCharacter->getCCPhysics()->setDuckingConvexShape(duck);

	mPhysics->getBroadphase()->getOverlappingPairCache()->setInternalGhostPairCallback(new btGhostPairCallback());

	mPhysics->getDynamicsWorld()->addCollisionObject(characterGhostObject, btBroadphaseProxy::CharacterFilter, btBroadphaseProxy::StaticFilter | btBroadphaseProxy::DefaultFilter);
	mPhysics->getDynamicsWorld()->addAction(mCharacter->getCCPhysics());

	/// --

	mPhysics->setRootSceneNode(mSceneManager->getRootSceneNode());
}